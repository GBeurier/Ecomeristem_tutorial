/**
 * @file artis/observer/View.hpp
 * @author See the AUTHORS file
 */

/*
 * Copyright (C) 2012-2019 ULCO http://www.univ-littoral.fr
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef ARTIS_OBSERVER_VIEW_HPP
#define ARTIS_OBSERVER_VIEW_HPP

#include <artis/kernel/AbstractModel.hpp>
#include <artis/utils/DoubleTime.hpp>

#include <boost/lexical_cast.hpp>

namespace artis {
namespace observer {

template<typename U, typename V>
class Probe {
public:
    const artis::kernel::AbstractModel<U,V>* model;
    std::string value_name;
    unsigned int value_index;
    kernel::ValueTypeID value_type;
    int model_index;

    Probe(const kernel::AbstractModel<U,V>* model, const std::string &value_name,
          unsigned int value_index, artis::kernel::ValueTypeID value_type, int model_index)
        : model(model),
          value_name(value_name),
          value_index(value_index),
          value_type(value_type),
          model_index(model_index)
    {}
};





template<typename U, typename V>
class View {
    typedef std::vector<unsigned int> Selector;

public:
    typedef std::vector<std::pair<double, std::string> > Value;

    typedef std::map<std::string, Value> Values;

    View()
        :_model(0) { }

    virtual ~View() { }

    void attachModel(const artis::kernel::AbstractModel<U, V>* m) { _model = m; }

    double begin() const
    {
        double t = utils::DoubleTime::infinity;

        for (Values::const_iterator it = _values.begin(); it != _values.end();
             ++it) {
            if (t > it->second.begin()->first) {
                t = it->second.begin()->first;
            }
        }
        return t;
    }

    View* clone() const
    {
        View* v = new View();

        v->_selectors = _selectors;
        for (Values::const_iterator it = _values.begin(); it != _values.end();
             ++it) {

            v->_values[it->first] = Value();
            Value::const_iterator itp = it->second.begin();

            while (itp != it->second.end()) {
                v->_values[it->first].push_back(*itp);
                ++itp;
            }
        }
        v->_model = 0;
        return v;
    }

    double end() const
    {
        double t = 0;

        for (Values::const_iterator it = _values.begin(); it != _values.end();
             ++it) {
            if (t < it->second.back().first) {
                t = it->second.back().first;
            }
        }
        return t;
    }

    double get(double t, const std::string& name) const
    {
        Values::const_iterator it = _values.find(name);

        if (it != _values.end()) {
            Value::const_iterator itp = it->second.begin();

            while (itp != it->second.end() and itp->first < t) {
                ++itp;
            }
            if (itp != it->second.end()) {
                // TODO: to improve
                return boost::lexical_cast<double>(itp->second);
            } else {
                return 0;
            }
        }
        return 0;
    }

    const Value& get(const std::string& name) const
    {
        Values::const_iterator it = _values.find(name);

        if (it != _values.end()) {
            return it->second;
        } else {
            assert(false);
        }
    }


    void update_probes(std::string name,
                       const Selector &path,
                       kernel::ValueTypeID type,
                       const kernel::Node<U>* model,
                       int model_index = 0)

    {
        if (path.size() > 1) {
            if(model->is_submodel_set(path.front())) {
                unsigned int rank = 0;
                const kernel::Node<U>* submodel =
                        model->get_submodel(path.front(), rank);
                while (submodel != 0) {
                    Selector new_path(path.begin() + 1, path.end());
                    update_probes(name,
                                  new_path,
                                  type,
                                  submodel,
                                  rank
                                  );
                    submodel = model->get_submodel(path.front(), ++rank);
                }
            } else {
                Selector new_path(path.begin() + 1, path.end());
                update_probes(name,
                              new_path,
                              type,
                              model->get_submodel(path.front()),
                              0
                              );
            }
        } else {
            std::string key =  name + '_' + std::to_string(model_index) + '_' + model->getUid();
            if (_probes.find( key ) == _probes.end()){
                _values[key] = Value();
                const kernel::AbstractModel<U,V>* added_model =
                        static_cast<const kernel::AbstractModel<U,V>*>(model);
                _probes[key] = new Probe<U,V>(added_model,
                                              name,
                                              path.back(),
                                              type,
                                              model_index);

                _values_meta[key] = std::make_pair(name, added_model->path(added_model));
            }
        }
    }

    virtual void observe(double time)
    {
        // update observation probes
        for (typename Selectors::const_iterator it = _selectors.begin();
             it != _selectors.end(); ++it) {

            const kernel::AbstractModel<U,V>* model = _model;

            update_probes(it->first, it->second.second, it->second.first, model);
        }


        // loop probes and add values
        for (auto it = _probes.begin(); it != _probes.end();
             it++) {

            Probe<U,V> * probe = it->second;
            if (probe->model) {

                try {
                     std::string val = probe->model->get(probe->value_type,
                                            time,
                                            probe->value_index);
                    _values[it->first]
                            .push_back(
                                std::make_pair(time, val));
                } catch(utils::InvalidGet e) {
                    _values[it->first]
                            .push_back(
                                std::make_pair(time, e.val));
                }


            }
        }
    }

    void selector(const std::string& name, kernel::ValueTypeID value_type,
                  const Selector& chain)
    {
        _selectors[name] = std::make_pair(value_type, chain);
    }

    const Values& values() const { return _values; }

    const std::string name(std::string key) { return _values_meta[key].first;}
    const std::string path(std::string key) { return _values_meta[key].second;}

private:
    typedef std::map<std::string, std::pair<kernel::ValueTypeID,
    Selector> > Selectors;

    Selectors _selectors;
    Values _values;
    const artis::kernel::AbstractModel<U, V>* _model;
    std::map<std::string, Probe<U,V>*> _probes;
    std::map<std::string, std::pair<std::string, std::string> > _values_meta;
};

}
}

#endif

