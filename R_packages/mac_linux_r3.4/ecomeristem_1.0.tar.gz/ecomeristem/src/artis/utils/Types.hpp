#ifndef TYPES_HPP
#define TYPES_HPP


namespace artis {
template <typename E, typename std::enable_if<std::is_enum<E>::value>::type* = nullptr>
class Flags {
public:
    int flags;

    bool operator&(E state) {
        return (flags & static_cast<int>(state)) != 0;
    }
    void operator<<(E state) {
        flags = flags | static_cast<int>(state);
    }
    void operator>>(E state) {
        flags = flags & ~static_cast<int>(state);
    }

    operator int() {
        return flags;
    }

    bool operator !=(const Flags& s) const{
        return this->flags != s.flags;
    }

    bool is(E state) {
        return (flags & static_cast<int>(state)) != 0;
    }
    void add(E state) {
        flags = flags | static_cast<int>(state);
    }
    void del(E state) {
        flags = flags & ~static_cast<int>(state);
    }

    void replace(E from, E to) {
        del(from);
        add(to);
    }
};

template <typename E, typename std::enable_if<std::is_enum<E>::value>::type* = nullptr>
inline bool operator&(Flags<E> a, Flags<E> b) {
    return (static_cast<int>(a) & static_cast<int>(b)) != 0;
}

template <typename E, typename std::enable_if<std::is_enum<E>::value>::type* = nullptr>
inline void operator<<(Flags<E>& a, Flags<E> b) {
    a = static_cast<Flags<E>>(static_cast<int>(a) | static_cast<int>(b));
}

template <typename E, typename std::enable_if<std::is_enum<E>::value>::type* = nullptr>
inline void operator>>(Flags<E>& a, Flags<E> b) {
    a = static_cast<Flags<E>>(static_cast<int>(a) & ~static_cast<int>(b));
}

}


#endif // TYPES_HPP
